<?php

namespace Drupal\insert_block_token\Plugin\Filter;

use Drupal\Core\Url;
use Drupal\Core\Form\FormStateInterface;
use Drupal\filter\Plugin\FilterBase;
use Drupal\filter\FilterProcessResult;

/**
 * Class InsertBlockFilter.
 *
 * Inserts blocks into the content.
 *
 * @package Drupal\insert_block_token\Plugin\Filter
 *
 * @Filter(
 *   id = "filter_insert_block_token",
 *   title = @Translation("Insert blocks"),
 *   description = @Translation("Inserts the contents of a block into a node using [block:block-entity-id] tags."),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_MARKUP_LANGUAGE,
 *   settings = {
 *     "check_roles" = TRUE
 *   }
 * )
 */
class InsertBlockTokenFilter extends FilterBase {

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode) { 
    if (preg_match_all("/\[block:([^\]]+)+\]/", $text, $match)) {
      $raw_tags = $repl = [];

      foreach ($match[1] as $key => $value) {
        $raw_tags[] = $match[0][$key];

        if (strpos($value, '=') !== FALSE) {
          $block_id_split = explode('=', $value); $block_id = $block_id_split[1];
        } else {
          $block_id = $value;
        }  

        $replacement = '';
        // Render blocks in code.
        if ($block = \Drupal::service('entity_type.manager')
        ->getStorage('block')
        ->load($block_id)) {
          $block_view = \Drupal::service('entity_type.manager')
            ->getViewBuilder('block')
            ->view($block);
          $replacement = \Drupal::service('renderer')->render($block_view);
        } 

        // Render custom blocks. 
        if ($block = \Drupal::service('entity_type.manager')
          ->getStorage('block_content')
          ->load($block_id)) {

          $block_view = \Drupal::service('entity_type.manager')
           ->getViewBuilder('block_content')
           ->view($block); $replacement = \Drupal::service('renderer')->render($block_view);
          } 
        $repl[] = $replacement;  
      }
      $text = str_replace($raw_tags, $repl, $text);
    }

    return new FilterProcessResult($text);

  }

  /**
   * {@inheritdoc}
   */
  public function tips($long = FALSE) {
    if ($long) {
      return $this->t('You may use [block:block_entity_id] to display the contents of block.');
    } else {
      $tips_url = Url::fromRoute("filter.tips_all", [], ['fragment' => 'filter-insert_block_token']);
      return $this->t('You may use [block:block_entity_id] to display the contents of block.', ["@insert_block_token_help" => $tips_url->toString()]);
    }
  }

}
